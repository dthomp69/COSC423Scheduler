package src;

/* Daniel Thompson, COSC 423 Simple Scheduler assignment. */

public class ImplementsJobWorkable implements JobWorkable {

	public ImplementsJobWorkable() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void doWork() {
		// TODO Auto-generated method stub

	}

}
